#include <stdint.h>

extern const uint8_t bsec_config_selectivity[2285];

