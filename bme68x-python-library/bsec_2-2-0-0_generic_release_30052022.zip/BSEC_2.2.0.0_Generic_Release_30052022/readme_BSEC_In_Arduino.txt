please refer to github 
https://github.com/BoschSensortec/Bosch-BSEC2-Library
https://github.com/BoschSensortec/Bosch-BME68x-Library